import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

interface ClubCardProps {
  slug: string;
  name: string;
  shortDesc: string;
  logoUrl?: string;
  roomCode: string;
  nextMeeting?: string;
}

export const ClubCard = ({ slug, name, shortDesc, logoUrl, roomCode, nextMeeting }: ClubCardProps) => {
  return (
    <Link to={`/clubs/${slug}-room-${roomCode}`}>
      <Card className="group h-full overflow-hidden border-border bg-card hover:shadow-hover transition-all duration-300 cursor-pointer">
        <div className="aspect-video w-full overflow-hidden bg-muted">
          {logoUrl ? (
            <img 
              src={logoUrl} 
              alt={`${name} logo`}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-primary">
              <span className="text-4xl font-bold text-primary-foreground">
                {name.charAt(0)}
              </span>
            </div>
          )}
        </div>
        <CardContent className="p-4 space-y-3">
          <div className="space-y-1">
            <h3 className="font-semibold text-lg text-card-foreground line-clamp-1 group-hover:text-primary transition-colors">
              {name}
            </h3>
            <p className="text-sm text-muted-foreground line-clamp-2">
              {shortDesc}
            </p>
          </div>
          
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="w-3 h-3" />
              <span>{roomCode}</span>
            </div>
            {nextMeeting && (
              <Badge variant="secondary" className="text-xs gap-1">
                <Clock className="w-3 h-3" />
                {nextMeeting}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
};
