import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

interface FilterChipsProps {
  filters: string[];
  onRemove: (filter: string) => void;
  label: string;
}

export const FilterChips = ({ filters, onRemove, label }: FilterChipsProps) => {
  if (filters.length === 0) return null;

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span className="text-sm text-muted-foreground">{label}:</span>
      {filters.map((filter) => (
        <Badge 
          key={filter} 
          variant="secondary" 
          className="gap-1 cursor-pointer hover:bg-destructive hover:text-destructive-foreground transition-colors"
          onClick={() => onRemove(filter)}
        >
          {filter}
          <X className="w-3 h-3" />
        </Badge>
      ))}
    </div>
  );
};
