import { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { MapPin, Mail, Users, Calendar, Instagram, Globe, MessageCircle, Linkedin, Twitch } from "lucide-react";
import { User } from "@supabase/supabase-js";

interface Club {
  id: string;
  slug: string;
  name: string;
  logo_url: string | null;
  short_desc: string;
  long_desc: string | null;
  room_code: string;
  advisor_name: string | null;
  contact_email: string | null;
  socials: any;
}

interface Event {
  id: string;
  title: string;
  description: string | null;
  start_ts: string;
  end_ts: string;
}

const ClubDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [club, setClub] = useState<Club | null>(null);
  const [events, setEvents] = useState<Event[]>([]);
  const [isMember, setIsMember] = useState(false);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (slug) {
      fetchClubDetails();
    }
  }, [slug, user]);

  const fetchClubDetails = async () => {
    if (!slug) return;

    try {
      // Extract slug and room from the URL format: club-slug-room-ROOM
      const slugParts = slug.split("-room-");
      const clubSlug = slugParts[0];

      const { data: clubData, error: clubError } = await supabase
        .from("clubs")
        .select("*")
        .eq("slug", clubSlug)
        .single();

      if (clubError) throw clubError;
      setClub(clubData);

      // Fetch events for this club
      const { data: eventsData } = await supabase
        .from("events")
        .select("*")
        .eq("club_id", clubData.id)
        .gte("end_ts", new Date().toISOString())
        .order("start_ts", { ascending: true })
        .limit(10);

      setEvents(eventsData || []);

      // Check membership if user is logged in
      if (user) {
        const { data: membershipData } = await supabase
          .from("memberships")
          .select("id")
          .eq("club_id", clubData.id)
          .eq("user_id", user.id)
          .maybeSingle();

        setIsMember(!!membershipData);
      }
    } catch (error: any) {
      console.error("Error fetching club:", error);
      toast.error("Failed to load club details");
      navigate("/");
    } finally {
      setLoading(false);
    }
  };

  const handleJoinLeave = async () => {
    if (!user) {
      toast.error("Please sign in to join clubs");
      navigate("/auth");
      return;
    }

    if (!club) return;

    setActionLoading(true);

    try {
      if (isMember) {
        // Leave club
        const { error } = await supabase
          .from("memberships")
          .delete()
          .eq("club_id", club.id)
          .eq("user_id", user.id);

        if (error) throw error;
        setIsMember(false);
        toast.success(`Left ${club.name}`);
      } else {
        // Join club
        const { error } = await supabase
          .from("memberships")
          .insert({
            club_id: club.id,
            user_id: user.id,
            role: "member",
          });

        if (error) throw error;
        setIsMember(true);
        toast.success(`Joined ${club.name}!`);
      }
    } catch (error: any) {
      console.error("Error:", error);
      toast.error(error.message || "An error occurred");
    } finally {
      setActionLoading(false);
    }
  };

  const getSocialIcon = (platform: string) => {
    switch (platform) {
      case "instagram": return <Instagram className="w-4 h-4" />;
      case "website": return <Globe className="w-4 h-4" />;
      case "discord": return <MessageCircle className="w-4 h-4" />;
      case "linkedin": return <Linkedin className="w-4 h-4" />;
      case "twitch": return <Twitch className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading club details...</p>
        </div>
      </div>
    );
  }

  if (!club) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate("/")}>
              ← Back
            </Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
                <span className="text-lg font-bold text-primary-foreground">C</span>
              </div>
              <h1 className="text-xl font-bold text-foreground">CampusConnect</h1>
            </div>
          </div>
          
          {user && (
            <Button variant="ghost" asChild>
              <Link to="/dashboard">Dashboard</Link>
            </Button>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-primary py-12">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto flex gap-6 items-start">
            <div className="flex-shrink-0">
              {club.logo_url ? (
                <img 
                  src={club.logo_url} 
                  alt={`${club.name} logo`}
                  className="w-24 h-24 rounded-xl object-cover border-4 border-white/20"
                />
              ) : (
                <div className="w-24 h-24 rounded-xl bg-white/10 backdrop-blur flex items-center justify-center border-4 border-white/20">
                  <span className="text-4xl font-bold text-white">
                    {club.name.charAt(0)}
                  </span>
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-4xl font-bold text-white mb-2">{club.name}</h1>
              <p className="text-white/90 text-lg mb-4">{club.short_desc}</p>
              <div className="flex flex-wrap gap-3">
                <Badge variant="secondary" className="gap-1 text-sm">
                  <MapPin className="w-4 h-4" />
                  Room {club.room_code}
                </Badge>
                {club.advisor_name && (
                  <Badge variant="secondary" className="gap-1 text-sm">
                    <Users className="w-4 h-4" />
                    Advisor: {club.advisor_name}
                  </Badge>
                )}
              </div>
            </div>
            <Button 
              size="lg"
              variant={isMember ? "outline" : "secondary"}
              onClick={handleJoinLeave}
              disabled={actionLoading}
              className="flex-shrink-0"
            >
              {actionLoading ? "Loading..." : isMember ? "Leave Club" : "Join Club"}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="about" className="w-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="events">Events</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-6 mt-6">
              {club.long_desc && (
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold mb-3">About the Club</h2>
                    <p className="text-muted-foreground leading-relaxed">{club.long_desc}</p>
                  </CardContent>
                </Card>
              )}

              <Card>
                <CardContent className="p-6 space-y-4">
                  <h2 className="text-xl font-semibold">Contact Information</h2>
                  
                  {club.contact_email && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="w-5 h-5" />
                      <a href={`mailto:${club.contact_email}`} className="hover:text-primary transition-colors">
                        {club.contact_email}
                      </a>
                    </div>
                  )}

                  {club.socials && Object.keys(club.socials).length > 0 && (
                    <div className="space-y-2">
                      <h3 className="text-sm font-medium">Social Media</h3>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(club.socials).map(([platform, handle]) => (
                          <Badge key={platform} variant="secondary" className="gap-1.5">
                            {getSocialIcon(platform)}
                            <span className="capitalize">{platform}</span>: {handle as string}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="events" className="space-y-4 mt-6">
              {events.length === 0 ? (
                <Card>
                  <CardContent className="p-12 text-center">
                    <Calendar className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-lg text-muted-foreground">
                      No upcoming events scheduled yet.
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Check back later for future events!
                    </p>
                  </CardContent>
                </Card>
              ) : (
                events.map((event) => (
                  <Card key={event.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">{event.title}</h3>
                          {event.description && (
                            <p className="text-muted-foreground mb-3">{event.description}</p>
                          )}
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {new Date(event.start_ts).toLocaleDateString("en-US", {
                                weekday: "long",
                                month: "long",
                                day: "numeric",
                                hour: "numeric",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default ClubDetail;
