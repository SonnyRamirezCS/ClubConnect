import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ClubCard } from "@/components/ClubCard";
import { toast } from "sonner";
import { User } from "@supabase/supabase-js";

interface Membership {
  club_id: string;
  clubs: {
    id: string;
    slug: string;
    name: string;
    short_desc: string;
    logo_url: string | null;
    room_code: string;
  };
}

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);
      fetchMemberships(session.user.id);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        navigate("/auth");
        return;
      }
      setUser(session.user);
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const fetchMemberships = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from("memberships")
        .select(`
          club_id,
          clubs (
            id,
            slug,
            name,
            short_desc,
            logo_url,
            room_code
          )
        `)
        .eq("user_id", userId);

      if (error) throw error;
      setMemberships(data || []);
    } catch (error) {
      console.error("Error fetching memberships:", error);
      toast.error("Failed to load your clubs");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <span className="text-lg font-bold text-primary-foreground">C</span>
            </div>
            <h1 className="text-xl font-bold text-foreground">CampusConnect</h1>
          </div>
          
          <Button variant="ghost" onClick={() => navigate("/")}>
            Browse Clubs
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container px-4 py-8 space-y-6">
        <div>
          <h2 className="text-3xl font-bold text-foreground mb-2">My Dashboard</h2>
          <p className="text-muted-foreground">
            Welcome back! Here are your clubs and upcoming events.
          </p>
        </div>

        {/* My Clubs Section */}
        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-foreground">My Clubs</h3>
          
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-72 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : memberships.length === 0 ? (
            <div className="text-center py-16 bg-muted rounded-lg">
              <p className="text-lg text-muted-foreground mb-4">
                You haven't joined any clubs yet.
              </p>
              <Button onClick={() => navigate("/")}>
                Browse Clubs
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {memberships.map((membership) => (
                <ClubCard
                  key={membership.clubs.id}
                  slug={membership.clubs.slug}
                  name={membership.clubs.name}
                  shortDesc={membership.clubs.short_desc}
                  logoUrl={membership.clubs.logo_url || undefined}
                  roomCode={membership.clubs.room_code}
                />
              ))}
            </div>
          )}
        </section>

        {/* Upcoming Events Section - Placeholder for future */}
        <section className="space-y-4">
          <h3 className="text-2xl font-bold text-foreground">Upcoming Events</h3>
          <div className="bg-muted rounded-lg p-8 text-center">
            <p className="text-muted-foreground">
              Event calendar coming soon! Check back later.
            </p>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Dashboard;
