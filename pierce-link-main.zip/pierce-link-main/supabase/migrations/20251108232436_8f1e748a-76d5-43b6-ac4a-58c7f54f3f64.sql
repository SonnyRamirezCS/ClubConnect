-- Create enum for membership roles
CREATE TYPE membership_role AS ENUM ('member', 'officer');

-- Create enum for check-in methods
CREATE TYPE checkin_method AS ENUM ('qr', 'pin');

-- Create majors table
CREATE TABLE public.majors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create tags table
CREATE TABLE public.tags (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create clubs table
CREATE TABLE public.clubs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  logo_url TEXT,
  short_desc TEXT NOT NULL,
  long_desc TEXT,
  room_code TEXT NOT NULL,
  advisor_name TEXT,
  contact_email TEXT,
  socials JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create club_majors junction table
CREATE TABLE public.club_majors (
  club_id UUID REFERENCES public.clubs(id) ON DELETE CASCADE,
  major_id UUID REFERENCES public.majors(id) ON DELETE CASCADE,
  PRIMARY KEY (club_id, major_id)
);

-- Create club_tags junction table
CREATE TABLE public.club_tags (
  club_id UUID REFERENCES public.clubs(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES public.tags(id) ON DELETE CASCADE,
  PRIMARY KEY (club_id, tag_id)
);

-- Create memberships table
CREATE TABLE public.memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  club_id UUID REFERENCES public.clubs(id) ON DELETE CASCADE,
  role membership_role NOT NULL DEFAULT 'member',
  joined_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, club_id)
);

-- Create events table
CREATE TABLE public.events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  club_id UUID REFERENCES public.clubs(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  start_ts TIMESTAMPTZ NOT NULL,
  end_ts TIMESTAMPTZ NOT NULL,
  rrule TEXT,
  pin_code TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create attendances table
CREATE TABLE public.attendances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES public.events(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  checkin_ts TIMESTAMPTZ DEFAULT now(),
  method checkin_method NOT NULL,
  UNIQUE(event_id, user_id)
);

-- Enable RLS on all tables
ALTER TABLE public.majors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.club_majors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.club_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendances ENABLE ROW LEVEL SECURITY;

-- RLS Policies for clubs (public read)
CREATE POLICY "Clubs are viewable by everyone"
  ON public.clubs FOR SELECT
  USING (true);

CREATE POLICY "Officers can update their clubs"
  ON public.clubs FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.memberships
      WHERE memberships.club_id = clubs.id
        AND memberships.user_id = auth.uid()
        AND memberships.role = 'officer'
    )
  );

-- RLS Policies for majors and tags (public read)
CREATE POLICY "Majors are viewable by everyone"
  ON public.majors FOR SELECT
  USING (true);

CREATE POLICY "Tags are viewable by everyone"
  ON public.tags FOR SELECT
  USING (true);

-- RLS Policies for club_majors and club_tags (public read)
CREATE POLICY "Club majors are viewable by everyone"
  ON public.club_majors FOR SELECT
  USING (true);

CREATE POLICY "Club tags are viewable by everyone"
  ON public.club_tags FOR SELECT
  USING (true);

-- RLS Policies for memberships
CREATE POLICY "Users can view all memberships"
  ON public.memberships FOR SELECT
  USING (true);

CREATE POLICY "Users can create their own memberships"
  ON public.memberships FOR INSERT
  WITH CHECK (auth.uid() = user_id AND role = 'member');

CREATE POLICY "Users can delete their own memberships"
  ON public.memberships FOR DELETE
  USING (auth.uid() = user_id);

-- RLS Policies for events (public read)
CREATE POLICY "Events are viewable by everyone"
  ON public.events FOR SELECT
  USING (true);

CREATE POLICY "Officers can create events for their clubs"
  ON public.events FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.memberships
      WHERE memberships.club_id = events.club_id
        AND memberships.user_id = auth.uid()
        AND memberships.role = 'officer'
    )
  );

CREATE POLICY "Officers can update events for their clubs"
  ON public.events FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.memberships
      WHERE memberships.club_id = events.club_id
        AND memberships.user_id = auth.uid()
        AND memberships.role = 'officer'
    )
  );

-- RLS Policies for attendances
CREATE POLICY "Users can view attendances for their clubs"
  ON public.attendances FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.events
      JOIN public.memberships ON memberships.club_id = events.club_id
      WHERE events.id = attendances.event_id
        AND memberships.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create their own check-ins"
  ON public.attendances FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_clubs_updated_at
  BEFORE UPDATE ON public.clubs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_events_updated_at
  BEFORE UPDATE ON public.events
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();